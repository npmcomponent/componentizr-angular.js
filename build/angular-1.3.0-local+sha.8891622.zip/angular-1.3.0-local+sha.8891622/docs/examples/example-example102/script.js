  function ControllerUpdateOn($scope) {
    $scope.user = {};
  }